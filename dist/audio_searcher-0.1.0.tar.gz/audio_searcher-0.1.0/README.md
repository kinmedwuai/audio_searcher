# Audio Searcher

Audio Searcher is a Python package that allows you to search for keywords in audio files.

## Installation

You can install the package using pip:

```sh
pip install audio_searcher

